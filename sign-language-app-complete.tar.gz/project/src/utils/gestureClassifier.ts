import type { NormalizedLandmarkList } from '../types/mediapipe';

export interface GestureResult {
  gesture: string;
  confidence: number;
}

function isFingerExtended(landmarks: NormalizedLandmarkList, fingerIndex: number): boolean {
  const fingerTips = [4, 8, 12, 16, 20];
  const fingerMCPs = [2, 5, 9, 13, 17];
  const fingerPIPs = [3, 6, 10, 14, 18];

  const tip = landmarks[fingerTips[fingerIndex]];
  const pip = landmarks[fingerPIPs[fingerIndex]];
  const mcp = landmarks[fingerMCPs[fingerIndex]];

  const tipToPipDist = Math.sqrt(
    Math.pow(tip.x - pip.x, 2) + Math.pow(tip.y - pip.y, 2)
  );
  const pipToMcpDist = Math.sqrt(
    Math.pow(pip.x - mcp.x, 2) + Math.pow(pip.y - mcp.y, 2)
  );

  return tip.y < pip.y - 0.02 || tipToPipDist > pipToMcpDist * 1.2;
}

function isFingersClose(landmarks: NormalizedLandmarkList, finger1: number, finger2: number): boolean {
  const fingerTips = [4, 8, 12, 16, 20];
  const tip1 = landmarks[fingerTips[finger1]];
  const tip2 = landmarks[fingerTips[finger2]];

  const distance = Math.sqrt(
    Math.pow(tip1.x - tip2.x, 2) + Math.pow(tip1.y - tip2.y, 2)
  );

  return distance < 0.05;
}

function getFingerStates(landmarks: NormalizedLandmarkList) {
  return {
    thumb: isFingerExtended(landmarks, 0),
    index: isFingerExtended(landmarks, 1),
    middle: isFingerExtended(landmarks, 2),
    ring: isFingerExtended(landmarks, 3),
    pinky: isFingerExtended(landmarks, 4)
  };
}

function recognizeGesture(landmarks: NormalizedLandmarkList): GestureResult {
  const { thumb, index, middle, ring, pinky } = getFingerStates(landmarks);

  const thumbTip = landmarks[4];
  const indexTip = landmarks[8];
  const middleTip = landmarks[12];
  const ringTip = landmarks[16];
  const pinkyTip = landmarks[20];
  const wrist = landmarks[0];
  const indexMCP = landmarks[5];
  const palmBase = landmarks[0];

  const thumbToIndex = Math.sqrt(
    Math.pow(thumbTip.x - indexTip.x, 2) + Math.pow(thumbTip.y - indexTip.y, 2)
  );
  const thumbToMiddle = Math.sqrt(
    Math.pow(thumbTip.x - middleTip.x, 2) + Math.pow(thumbTip.y - middleTip.y, 2)
  );

  if (!thumb && !index && !middle && !ring && !pinky) {
    if (thumbTip.x > indexMCP.x - 0.02) {
      return { gesture: 'A', confidence: 0.95 };
    }
    return { gesture: 'S', confidence: 0.93 };
  }

  if (!thumb && index && middle && ring && pinky) {
    const allFingersClose =
      Math.abs(indexTip.y - middleTip.y) < 0.03 &&
      Math.abs(middleTip.y - ringTip.y) < 0.03 &&
      Math.abs(ringTip.y - pinkyTip.y) < 0.03;

    if (allFingersClose) {
      return { gesture: 'B', confidence: 0.94 };
    }
  }

  if (thumb && !index && !middle && !ring && !pinky) {
    const thumbCurved = thumbToIndex < 0.12;
    if (thumbCurved) {
      return { gesture: 'C', confidence: 0.92 };
    }
  }

  if (!thumb && index && !middle && !ring && !pinky) {
    if (thumbTip.x > indexMCP.x) {
      return { gesture: 'D', confidence: 0.94 };
    }
    return { gesture: 'I', confidence: 0.90 };
  }

  if (!thumb && !index && !middle && !ring && !pinky && thumbTip.y < wrist.y) {
    const fingersCurled = indexTip.y > indexMCP.y;
    if (fingersCurled) {
      return { gesture: 'E', confidence: 0.93 };
    }
  }

  if (thumb && index && middle && !ring && !pinky) {
    if (isFingersClose(landmarks, 0, 1) && isFingersClose(landmarks, 1, 2)) {
      return { gesture: 'F', confidence: 0.93 };
    }
    if (thumbToIndex < 0.08) {
      return { gesture: 'O', confidence: 0.91 };
    }
  }

  if (thumb && index && !middle && !ring && !pinky) {
    const pointingHorizontal = indexTip.x < thumbTip.x - 0.05;
    if (pointingHorizontal) {
      return { gesture: 'G', confidence: 0.92 };
    }
  }

  if (!thumb && index && middle && !ring && !pinky) {
    const pointingHorizontal =
      Math.abs(indexTip.x - middleTip.x) < 0.03 &&
      indexTip.x < palmBase.x - 0.05;

    if (pointingHorizontal) {
      return { gesture: 'H', confidence: 0.92 };
    }
    return { gesture: 'U', confidence: 0.90 };
  }

  if (!thumb && !index && !middle && !ring && pinky) {
    return { gesture: 'I', confidence: 0.94 };
  }

  if (!thumb && !index && !middle && !ring && pinky) {
    const pinkyMoving = pinkyTip.y < wrist.y - 0.1;
    if (pinkyMoving) {
      return { gesture: 'J', confidence: 0.88 };
    }
  }

  if (!thumb && index && middle && !ring && !pinky) {
    const spreadApart = Math.abs(indexTip.x - middleTip.x) > 0.08;
    if (spreadApart) {
      return { gesture: 'K', confidence: 0.91 };
    }
    return { gesture: 'V', confidence: 0.93 };
  }

  if (thumb && index && !middle && !ring && !pinky) {
    const lShape =
      indexTip.y < indexMCP.y - 0.05 &&
      thumbTip.x > indexMCP.x + 0.05;

    if (lShape) {
      return { gesture: 'L', confidence: 0.94 };
    }
  }

  if (!thumb && !index && !middle && !ring && !pinky) {
    const thumbBetweenFingers =
      thumbTip.y > indexMCP.y &&
      thumbTip.y < wrist.y;

    if (thumbBetweenFingers) {
      return { gesture: 'M', confidence: 0.91 };
    }
  }

  if (!thumb && !index && !middle && !ring && !pinky) {
    const thumbBetweenIndexMiddle =
      thumbTip.y > landmarks[6].y &&
      thumbTip.y < landmarks[5].y;

    if (thumbBetweenIndexMiddle) {
      return { gesture: 'N', confidence: 0.90 };
    }
  }

  if (thumb && index && middle && !ring && !pinky) {
    if (thumbToIndex < 0.06 && thumbToMiddle < 0.06) {
      return { gesture: 'O', confidence: 0.93 };
    }
  }

  if (!thumb && index && middle && !ring && !pinky) {
    const pointingDown = indexTip.y > indexMCP.y && middleTip.y > landmarks[9].y;
    if (pointingDown) {
      return { gesture: 'P', confidence: 0.91 };
    }
  }

  if (thumb && index && !middle && !ring && !pinky) {
    const pointingDown = indexTip.y > indexMCP.y;
    if (pointingDown) {
      return { gesture: 'Q', confidence: 0.90 };
    }
  }

  if (!thumb && index && middle && !ring && !pinky) {
    const crossed =
      indexTip.x > middleTip.x &&
      Math.abs(indexTip.y - middleTip.y) < 0.04;

    if (crossed) {
      return { gesture: 'R', confidence: 0.92 };
    }
  }

  if (!thumb && !index && !middle && !ring && !pinky) {
    const thumbOverFingers = thumbTip.y < indexMCP.y - 0.03;
    if (thumbOverFingers) {
      return { gesture: 'S', confidence: 0.94 };
    }
    return { gesture: 'A', confidence: 0.92 };
  }

  if (thumb && !index && !middle && !ring && !pinky) {
    const thumbBetweenIndexMiddle =
      thumbTip.y > landmarks[5].y &&
      thumbTip.y < landmarks[9].y &&
      thumbTip.x < indexMCP.x;

    if (thumbBetweenIndexMiddle) {
      return { gesture: 'T', confidence: 0.93 };
    }
  }

  if (!thumb && index && middle && !ring && !pinky) {
    const together = Math.abs(indexTip.x - middleTip.x) < 0.03;
    if (together) {
      return { gesture: 'U', confidence: 0.93 };
    }
    return { gesture: 'V', confidence: 0.92 };
  }

  if (!thumb && index && middle && !ring && !pinky) {
    const spread = Math.abs(indexTip.x - middleTip.x) > 0.05;
    if (spread) {
      return { gesture: 'V', confidence: 0.94 };
    }
  }

  if (!thumb && index && middle && ring && !pinky) {
    return { gesture: 'W', confidence: 0.93 };
  }

  if (!thumb && index && !middle && !ring && !pinky) {
    const bentIndex =
      indexTip.y > landmarks[6].y &&
      indexTip.x < indexMCP.x;

    if (bentIndex) {
      return { gesture: 'X', confidence: 0.91 };
    }
  }

  if (thumb && !index && !middle && !ring && pinky) {
    return { gesture: 'Y', confidence: 0.94 };
  }

  if (!thumb && index && !middle && !ring && !pinky) {
    const diagonal =
      indexTip.x < indexMCP.x - 0.05 &&
      indexTip.y < indexMCP.y - 0.05;

    if (diagonal) {
      return { gesture: 'Z', confidence: 0.89 };
    }
  }

  if (thumb && index && middle && ring && pinky) {
    return { gesture: 'SPACE', confidence: 0.85 };
  }

  if (!thumb && !index && !middle && !ring && !pinky) {
    const sidewaysFist = Math.abs(thumbTip.x - indexMCP.x) > 0.08;
    if (sidewaysFist) {
      return { gesture: 'DELETE', confidence: 0.87 };
    }
  }

  return { gesture: 'UNKNOWN', confidence: 0.50 };
}

export class GestureClassifier {
  private lastGesture: string | null = null;
  private gestureHoldCount = 0;
  private readonly holdThreshold = 10;
  private recentGestures: GestureResult[] = [];
  private lastEmittedGesture: string | null = null;
  private cooldownFrames = 0;
  private readonly cooldownThreshold = 15;

  classify(landmarks: NormalizedLandmarkList | undefined): GestureResult | null {
    if (!landmarks || landmarks.length !== 21) {
      this.reset();
      return null;
    }

    if (this.cooldownFrames > 0) {
      this.cooldownFrames--;
      return null;
    }

    const result = recognizeGesture(landmarks);

    if (result.confidence < 0.85 || result.gesture === 'UNKNOWN') {
      return null;
    }

    this.recentGestures.push(result);
    if (this.recentGestures.length > 7) {
      this.recentGestures.shift();
    }

    const mostCommon = this.getMostCommonGesture();

    if (mostCommon.gesture === this.lastGesture) {
      this.gestureHoldCount++;
    } else {
      this.lastGesture = mostCommon.gesture;
      this.gestureHoldCount = 1;
    }

    if (this.gestureHoldCount >= this.holdThreshold) {
      if (mostCommon.gesture !== this.lastEmittedGesture) {
        this.lastEmittedGesture = mostCommon.gesture;
        this.cooldownFrames = this.cooldownThreshold;
        this.gestureHoldCount = 0;
        return mostCommon;
      }
    }

    return null;
  }

  private getMostCommonGesture(): GestureResult {
    const gestureCounts = new Map<string, { count: number; totalConfidence: number }>();

    for (const result of this.recentGestures) {
      const current = gestureCounts.get(result.gesture) || { count: 0, totalConfidence: 0 };
      gestureCounts.set(result.gesture, {
        count: current.count + 1,
        totalConfidence: current.totalConfidence + result.confidence
      });
    }

    let maxCount = 0;
    let mostCommon = { gesture: 'UNKNOWN', confidence: 0 };

    for (const [gesture, data] of gestureCounts.entries()) {
      if (data.count > maxCount) {
        maxCount = data.count;
        mostCommon = {
          gesture,
          confidence: data.totalConfidence / data.count
        };
      }
    }

    return mostCommon;
  }

  reset(): void {
    this.lastGesture = null;
    this.gestureHoldCount = 0;
    this.recentGestures = [];
  }
}
