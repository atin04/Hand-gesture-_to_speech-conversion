# Sign Language to Text Recognition

Real-time ASL (American Sign Language) alphabet recognition application using hand tracking and AI.

## Features

- Real-time hand gesture recognition for ASL alphabet (A-Z)
- Support for SPACE and DELETE gestures
- Live video feed with hand landmark visualization
- Text output with character counter
- Save recognized text to file
- Clean, modern desktop-style interface

## Prerequisites

Before running this project, ensure you have:

- Node.js (v16 or higher)
- npm (comes with Node.js)
- A webcam
- Modern web browser (Chrome, Edge, or Firefox recommended)

## Installation & Setup

1. **Extract the project files** to a folder on your computer

2. **Open the project in VS Code:**
   - Launch Visual Studio Code
   - Click `File` → `Open Folder`
   - Select the project folder

3. **Install dependencies:**
   - Open the VS Code terminal (`Terminal` → `New Terminal` or `` Ctrl+` ``)
   - Run the following command:
   ```bash
   npm install
   ```

4. **Start the development server:**
   ```bash
   npm run dev
   ```

5. **Open the application:**
   - The terminal will show a URL (usually `http://localhost:5173`)
   - Hold `Ctrl` (or `Cmd` on Mac) and click the URL
   - Or manually open your browser and go to `http://localhost:5173`

## How to Use

1. **Start Camera:** Click the "Start Camera" button to enable your webcam
2. **Position Your Hand:** Show your hand clearly in the video feed
3. **Make Gestures:** Hold each ASL alphabet sign for about 1 second
4. **View Results:** Recognized letters appear in the text output area
5. **Clear Text:** Click "Clear All" to erase the text
6. **Save Text:** Click "Save to a Text File" to download your text
7. **Stop:** Click "Quit" to stop the camera

## Supported Gestures

- **A-Z:** All ASL alphabet letters
- **SPACE:** Open hand with all fingers extended
- **DELETE:** Closed fist (removes last character)

## Tips for Best Results

- Keep your hand well-lit and clearly visible
- Hold each gesture steady for 1 second
- Position your hand within the orange bounding box
- Practice with the ASL alphabet reference chart
- Avoid fast movements between gestures

## Project Structure

```
sign-language-app/
├── src/
│   ├── components/       # React components
│   ├── hooks/           # Custom React hooks
│   ├── services/        # Session management
│   ├── utils/           # Gesture recognition logic
│   ├── lib/             # Supabase client
│   ├── App.tsx          # Main application
│   └── main.tsx         # Entry point
├── public/              # Static assets
├── package.json         # Dependencies
└── README.md           # This file
```

## Building for Production

To create a production build:

```bash
npm run build
```

The built files will be in the `dist/` folder.

## Troubleshooting

**Camera not working:**
- Allow camera permissions when prompted
- Check if another application is using the camera
- Try refreshing the page

**Gestures not recognized:**
- Ensure good lighting
- Keep your hand steady for 1 second
- Position hand clearly in frame
- Check that only one hand is visible

**Application won't start:**
- Delete `node_modules` folder and run `npm install` again
- Ensure Node.js is installed: `node --version`
- Try a different port: `npm run dev -- --port 3000`

## Technologies Used

- React + TypeScript
- Vite (build tool)
- TailwindCSS (styling)
- MediaPipe Hands (hand tracking)
- Supabase (database)
- Lucide React (icons)

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+

## License

This project is provided as-is for educational purposes.
